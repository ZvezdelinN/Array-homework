﻿/*
Problem 13.* Merge sort
• Write a program that sorts an array of integers using the Merge sort algorithm.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Merge_Sort
{
    class Merge_Sort
    {

        public static void MergeSort(int[] ArrayToSort, int intStart, int intEnd)
        {
            if (intStart < intEnd)
            {
                int middle = intStart + ((intEnd - intStart) / 2);

                int[] leftArray;
                int[] rightArray;
                int intLeftArrayCounter = 0;
                int intArrayRightCounter = 0;

                MergeSort(ArrayToSort, intStart, middle);
                MergeSort(ArrayToSort, middle + 1, intEnd);

                //Merge
                leftArray = new int[middle - intStart + 1];
                rightArray = new int[intEnd - middle];

                Array.Copy(ArrayToSort, intStart, leftArray, 0, middle - intStart + 1);
                Array.Copy(ArrayToSort, middle + 1, rightArray, 0, intEnd - middle);
                
                for (int k = intStart; k < intEnd + 1; k++)
                {
                    if (intLeftArrayCounter == leftArray.Length)
                    {
                        ArrayToSort[k] = rightArray[intArrayRightCounter];
                        intArrayRightCounter++;
                    }
                    else if (intArrayRightCounter == rightArray.Length)
                    {
                        ArrayToSort[k] = leftArray[intLeftArrayCounter];
                        intLeftArrayCounter++;
                    }
                    else if (leftArray[intLeftArrayCounter] <= rightArray[intArrayRightCounter])
                    {
                        ArrayToSort[k] = leftArray[intLeftArrayCounter];
                        intLeftArrayCounter++;
                    }
                    else
                    {
                        ArrayToSort[k] = rightArray[intArrayRightCounter];
                        intArrayRightCounter++;
                    }
                }
            }
        }


        

        static void Main(string[] args)
        {
            int[] intArray = new int[10] { 1, 7, 4, 9, 2, 0, 3, 5, 8, 6 };

            MergeSort(intArray, 0, intArray.Length-1);

            for (int i = 0; i < intArray.Length; i++)
            {
                Console.Write(intArray[i]+", ");
            }
        }
    }
}
