﻿/*
Problem 3. Compare char arrays
• Write a program that compares two  char  arrays lexicographically (letter by letter).
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compare_char_arrays
{
    class Compare_char_arrays
    {
        public static void CompareArrays(char[] charArray1ToCompare, char[] charArray2)
        {
            for (int i = 0; i < charArray1ToCompare.Length; i++)
            {
                if (charArray1ToCompare[i] == charArray2[i])
                {
                    Console.WriteLine("The elemets {0} of both arrays are equal", i);
                }
                else
                {
                    Console.WriteLine("The elemets {0} of both arrays aren't equal", i);
                }
            }
        }

        static void Main(string[] args)
        {
            char[] charArray1;
            char[] charArray2;

            charArray1 = new char[5] {'F','G','/','.',' '};
            charArray2 = new char[5] {'f','g','/',',',' '};



            if (charArray1.Length > charArray2.Length)
            {
                CompareArrays(charArray2, charArray1);
            }
            else if (charArray1.Length < charArray2.Length)
            {
                CompareArrays(charArray1, charArray2);
            }
            else
            {
                CompareArrays(charArray1, charArray2);
            }
        }
    }
}
