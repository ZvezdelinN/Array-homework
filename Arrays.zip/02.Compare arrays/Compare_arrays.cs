﻿/*
Compare arrays
• Write a program that reads two  integer  arrays from the console and compares them element by element.
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compare_arrays
{
    class Compare_arrays
    {
        public static void CompareArrays(int[] intArray1ToCompare,int[] intArray2)
        {
            for (int i = 0; i < intArray1ToCompare.Length; i++)
            {
                if (intArray1ToCompare[i] == intArray2[i])
                {
                    Console.WriteLine("The elemets {0} of both arrays are equal", i);
                }
                else
                {
                    Console.WriteLine("The elemets {0} of both arrays aren't equal", i);
                }
            }
        }

        static void Main(string[] args)
        {
            int intArray1Elements;
            int intArray2Elements;

            int[] intArray1;
            int[] intArray2;

            Console.Write("Please enter the number of the elements of the first array : ");
            intArray1Elements = int.Parse(Console.ReadLine());

            intArray1 = new int[intArray1Elements];

            for (int i = 0; i < intArray1Elements; i++)
            {
                Console.Write("Element {0} = ", i);
                intArray1[i]=int.Parse(Console.ReadLine());
            }

            Console.Write("Please enter the number of the elements of the second array : ");
            intArray2Elements = int.Parse(Console.ReadLine());

            intArray2 = new int[intArray2Elements];

            for (int i = 0; i < intArray2Elements; i++)
            {
                Console.Write("Element {0} = ",i);
                intArray2[i] = int.Parse(Console.ReadLine());
            }

            if (intArray1.Length > intArray2.Length)
            {
                CompareArrays(intArray2, intArray1);
            }
            else if (intArray1.Length < intArray2.Length)
            {
                CompareArrays(intArray1, intArray2);
            }
            else
            {
                CompareArrays(intArray1, intArray2);
            }
        }
    }
}
