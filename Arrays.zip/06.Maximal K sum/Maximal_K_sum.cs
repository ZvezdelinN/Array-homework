﻿/*
Problem 6. Maximal K sum
• Write a program that reads two integer numbers  N  and  K  and an array of  N  elements from the console.
• Find in the array those  K  elements that have maximal sum.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Maximal_K_sum
{
    class Maximal_K_sum
    {
        static void Main(string[] args)
        {
            int intNumberOfElements;
            int intNumberOfElementsToSum;
            int[] intArray;
            int intMaxsum = 0;
            

            Console.WriteLine("Please, enter the numbers of the array : ");
            intNumberOfElements = int.Parse(Console.ReadLine());
            intArray=new int[intNumberOfElements];

            for (int i = 0; i < intNumberOfElements; i++)
            {
                Console.Write("Element {0} = ",i);
                intArray[i]=int.Parse(Console.ReadLine());
            }

            Console.WriteLine("Please, enter the numbers of the elements to sum : ");
            intNumberOfElementsToSum = int.Parse(Console.ReadLine());

            Array.Sort(intArray);

            for (int i = intArray.Length-intNumberOfElementsToSum; i < intArray.Length; i++)
            {
                intMaxsum += intArray[i];
            }

            Console.WriteLine("The max sum of {0} = {1}",intNumberOfElementsToSum,intMaxsum);
        }
    }
}
