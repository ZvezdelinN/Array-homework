﻿/*
Problem 9. Frequent number
• Write a program that finds the most frequent number in an array.

Example:


input                                           result


4, 1, 1, 4, 2, 3, 4, 4, 1, 2, 4, 9, 3       4 (5 times) 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _09.Frequent_number
{
    class Frequent_number
    {
        static void Main(string[] args)
        {
            int[] intArray = new int[] { 4, 1, 1, 4, 2, 3, 4, 4, 1, 2, 4, 9, 3 };
            int intCurrentElement = 0;
            int intCurentNumber = 0;
            int intCounter;

            intCounter = 1;

            for (int j = 0; j < intArray.Length; j++)
            {
                for (int i = 1; i < intArray.Length; i++)
                {
                    if(intArray[i]==intArray[j])
                    {
                        intCounter++;
                    }
                }
                if(intCurentNumber<intCounter)
                {
                    intCurentNumber = intCounter;
                    intCurrentElement = intArray[j];
                }
                intCounter = 1;
            }

            Console.WriteLine("{0} ({1} times)", intCurrentElement, intCurentNumber);
        }
    }
}
