﻿/*
Problem 5. Maximal increasing sequence
• Write a program that finds the maximal increasing sequence in an array.

Example:


input                     result


3, 2, 3, 4, 2, 2, 4      2, 3, 4 
 */ 


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Maximal_increasing_sequence
{
    class Maximal_increasing_sequence
    {
        static void Main(string[] args)
        {
            int[] intArray = new int[] { 3, 2, 3, 4, 5, 6, 4 };
            int[] intMaxSequenceValue = new int[intArray.Length];
            int intMaxsequence = 1;

            for (int i = 0; i < intArray.Length-1; i++)
            {
                if (intArray[i+1] - intArray[i]==1)
                {
                    intMaxsequence++;
                    intMaxSequenceValue[i] = intMaxsequence;
                }

                else
                {
                    intMaxsequence = 1;
                }

                Console.Write(intMaxsequence);
            }
            
            intMaxsequence = Array.IndexOf(intMaxSequenceValue, intMaxSequenceValue.Max());

            for (int i = intMaxSequenceValue.Max() - intMaxsequence; i <= intMaxsequence + 1; i++)
            {

                Console.Write(intArray[i]+", ");
            }


            Console.WriteLine();
        }
    }
}
