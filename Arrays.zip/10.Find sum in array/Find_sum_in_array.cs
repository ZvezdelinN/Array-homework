﻿/*
Problem 10. Find sum in array
• Write a program that finds in given array of integers a sequence of given sum  S  (if present).

Example:

array                    S           result


4, 3, 1, 4, 2, 5, 8     11          4, 2, 5 
*/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Find_sum_in_array
{
    class Find_sum_in_array
    {
        static void Main(string[] args)
        {
            int[] intArray = new int[] { 4, 3, 1, 4, 2, 5, 8 };
            int intSumToFind = 7;
            int intNumberCounter = 1;
            int intStartPosition = 0;
            int intCurentSum = 0;

            for (int i = 0; i < intArray.Length; i++)
            {
                intNumberCounter = 1;
                intCurentSum = intArray[i];
                for (int j = i+1; j < intArray.Length; j++)
			    {
                    intCurentSum += intArray[j];
                    if(intCurentSum > intSumToFind)
                    {
                        intCurentSum = 0;
                        break;
                    }
                    else if(intCurentSum < intSumToFind)
                    {
                        intNumberCounter++;
                        intStartPosition = i;
                    }
                    else
                    {
                        intNumberCounter++;
                        for (int z = intStartPosition; z < intStartPosition + intNumberCounter; z++)
                        {
                            Console.Write(intArray[z] + ", ");
                        }
                        return;
                    }
                }
            }
        }
    }
}
