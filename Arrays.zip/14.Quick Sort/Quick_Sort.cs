﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quick_Sort
{
    class Quick_Sort
    {

         public static void QuickSort(int[] ArrayToSort, int intStart, int intEnd)
         {
             if (intStart < intEnd)
             {
                 int q = Partition(ArrayToSort, intStart, intEnd);
                 QuickSort(ArrayToSort, intStart, q - 1);
                 QuickSort(ArrayToSort, q + 1, intEnd);
             }
         }


         private static int Partition(int[] ArrayToSort, int intStart, int intEnd)
         {
             int pivot = ArrayToSort[intEnd];
             int temp;
          
             int i = intStart;
             for (int j = intStart; j < intEnd; j++)
             {
                 if (ArrayToSort[j] <= pivot)
                 {
                     temp = ArrayToSort[j];
                     ArrayToSort[j] = ArrayToSort[i];
                     ArrayToSort[i] = temp;
                     i++;
                 }
             }

             ArrayToSort[intEnd] = ArrayToSort[i];
             ArrayToSort[i] = pivot;
          
             return i;
         }
          


        static void Main(string[] args)
        {
            int[] intArray = new int[10] { 1, 7, 4, 9, 2, 0, 3, 5, 8, 6 };

            QuickSort(intArray, 0, intArray.Length - 1);

            for (int i = 0; i < intArray.Length; i++)
            {
                Console.Write(intArray[i] + ", ");
            }
        }
    }
}
