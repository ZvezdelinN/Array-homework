﻿/*
Problem 4. Maximal sequence
• Write a program that finds the maximal sequence of equal elements in an array.

Example:


input                                 result


2, 1, 1, 2, 3, 3, 2, 2, 2, 1         2, 2, 2 
 */

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace Maximal_sequence
{
    class Maximal_sequence
    {
        static void Main(string[] args)
        {
            int[] intArray = new int[] { 2, 1, 1, 2, 3, 3, 3, 3, 3, 2, 2, 2, 1 };
            int[] intArraySequenceValue = new int[intArray.Length];
            int intMaxsequence = 1;
           
            for (int i = 1; i < intArray.Length; i++)
            {
                if(intArray[i]==intArray[i-1])
                {
                    intMaxsequence++;
                    intArraySequenceValue[i] = intMaxsequence;
                }

                else
                {
                    intMaxsequence = 1;
                }
            }

            intMaxsequence = Array.IndexOf(intArraySequenceValue, intArraySequenceValue.Max());

            for (int i = intMaxsequence; i > intMaxsequence - intArraySequenceValue.Max(); i--)
            {
                if (i == (intMaxsequence - intArraySequenceValue.Max()) + 1)
                {
                    Console.Write(intArray[i]);
                }
                else
                {
                    Console.Write(intArray[i] + ", ");
                }
            }
            


            Console.WriteLine();
         }
    }
}

