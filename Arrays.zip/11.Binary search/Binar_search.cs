﻿/*
Problem 11. Binary search
• Write a program that finds the index of given element in a sorted array of integers by using the Binary search algorithm.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Binary_search
{
    class Binar_search
    {
        public static int FindIndex(int[] intArrayToSearch,int intNumberToFind,int intStartPosition,int intEndPosition)
        {
            int intArrayIndex = intStartPosition + ((intEndPosition - intStartPosition) / 2);
            if (intArrayToSearch[intArrayIndex] > intNumberToFind)
            {
                intEndPosition=(intArrayIndex);
                return FindIndex(intArrayToSearch, intNumberToFind, intStartPosition, intEndPosition);
            }
            else if (intArrayToSearch[intArrayIndex] < intNumberToFind)
            {
                intStartPosition = (intArrayIndex)+1;
                return FindIndex(intArrayToSearch, intNumberToFind, intStartPosition, intEndPosition);
            }
            else 
            {
                return intArrayIndex;
            }
        }

        static void Main(string[] args)
        {
            int[] intArray = new int[]{0,1,2,3,4,5,6,7,8,9};
            int intNumberToSearch = 9;
            int intIndex = 0;
            int intStartIndex = 0;
            int intEndIndex = intArray.Length - 1;

            if (intNumberToSearch < 0 || intNumberToSearch > intArray[intArray.Length-1])
            {
                Console.WriteLine("The number {0} is not found!",intNumberToSearch);
            }
            else
            {
                intIndex = FindIndex(intArray, intNumberToSearch, intStartIndex, intEndIndex);

                Console.WriteLine("The index of {0} is {1}",intNumberToSearch, intIndex);
            }
        }
    }
}
