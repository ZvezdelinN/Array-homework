﻿/*
Problem 12. Index of letters
• Write a program that creates an array containing all letters from the alphabet ( A-Z ).
• Read a word from the console and print the index of each of its letters in the array.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Index_of_letters
{
    class Index_of_letters
    {
        static void Main(string[] args)
        {
            char[] chrArrayOfAlphabet=new char[91-65];
            char[] chrArrayOfString;
            string strWord = Console.ReadLine();
            bool boolFlag = false;

            chrArrayOfString = new char[strWord.Length];
            chrArrayOfString = strWord.ToCharArray();            

            for (int i = 65; i < 91; i++)
            {
                chrArrayOfAlphabet[i-65] = (char)i;
            }

            for (int i = 0; i < chrArrayOfString.Length; i++)
            {
                boolFlag = false;
                foreach(char ch in chrArrayOfAlphabet)
                {
                    if(ch==chrArrayOfString[i])
                    {
                        Console.WriteLine("{0} = {1}",chrArrayOfString[i].ToString(), Array.IndexOf(chrArrayOfAlphabet,chrArrayOfString[i]));
                        boolFlag = true;
                    }
                }
                if(!boolFlag)
                {
                    Console.WriteLine("{0} - not found", chrArrayOfString[i].ToString());
                }
            }
        }
    }
}
