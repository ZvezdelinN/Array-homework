﻿/*
Problem 7. Selection sort
• Sorting an array means to arrange its elements in increasing order. Write a program to sort an array.
• Use the Selection sort algorithm: Find the smallest element, move it at the first position, find the smallest from the rest, move it at the second position, etc.
 */ 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Selection_sort
{
    class Selection_sort
    {
        static void Main(string[] args)
        {
            int[] intArray = new int[] { 1, 7, 4, 9, 2, 0, 3, 5, 8, 6 };

            for (int i = 0; i < intArray.Length; i++)
            {
                for (int j = i+1; j < intArray.Length; j++)
                {
                    if(intArray[i]>intArray[j])
                    {
                        intArray[i] ^= intArray[j];
                        intArray[j] ^= intArray[i];
                        intArray[i] ^= intArray[j];
                    }
                }
            }

            for (int i = 0; i < intArray.Length; i++)
            {
                Console.Write("{0}, ",intArray[i]);
            }
        }
    }
}
